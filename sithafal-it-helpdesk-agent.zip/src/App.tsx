import { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Sliders, 
  Wrench, 
  Copy, 
  Check, 
  RotateCcw, 
  Send, 
  MessageSquare, 
  Settings, 
  ShieldCheck, 
  Info, 
  Sparkles, 
  HelpCircle,
  FileCode,
  CheckCircle2,
  Lock,
  ArrowRight
} from 'lucide-react';
import { PROMPT_TEMPLATES, QUICK_ISSUES } from './PromptTemplates';
import { ChatMessage, PromptConfig, ToneType } from './types';

// Simple, reliable inline renderer for SithaIT's markdown-like bullet guides
const renderMarkdown = (text: string) => {
  if (!text) return null;
  
  const lines = text.split('\n');
  return lines.map((line, idx) => {
    // Header check
    if (line.startsWith('### ')) {
      return <h4 key={idx} className="text-sm font-semibold text-slate-800 mt-2 mb-1">{line.replace('### ', '')}</h4>;
    }
    
    // Bold highlight blocks
    const boldRegex = /\*\*(.*?)\*\*/g;
    let parts = [];
    let lastIndex = 0;
    let match;
    
    // Check if line is custom warning/simulated block
    const isAlert = line.includes('[Simulated Response');
    
    // Check for bullet list item
    const isBullet = line.trim().startsWith('- ') || line.trim().startsWith('* ');
    const isNumbered = /^\d+\.\s/.test(line.trim());
    
    let contentStr = line;
    if (isBullet) {
      contentStr = line.trim().substring(2);
    } else if (isNumbered) {
      contentStr = line.trim().substring(line.trim().indexOf(' ') + 1);
    }
    
    // Parse bold text
    while ((match = boldRegex.exec(contentStr)) !== null) {
      if (match.index > lastIndex) {
        parts.push(contentStr.substring(lastIndex, match.index));
      }
      parts.push(<strong key={match.index} className="font-semibold text-slate-950">{match[1]}</strong>);
      lastIndex = boldRegex.lastIndex;
    }
    if (lastIndex < contentStr.length) {
      parts.push(contentStr.substring(lastIndex));
    }
    
    const finalContent = parts.length > 0 ? parts : contentStr;
    
    if (isAlert) {
      return (
        <div key={idx} className="my-2 p-3 bg-indigo-50/80 border border-indigo-100 rounded-lg text-xs text-indigo-700 font-medium font-sans">
          {finalContent}
        </div>
      );
    }
    
    if (isBullet) {
      return (
        <li key={idx} className="ml-4 list-disc text-sm text-slate-700 leading-relaxed my-1">
          {finalContent}
        </li>
      );
    }
    
    if (isNumbered) {
      const matchNum = line.trim().match(/^(\d+)\.\s/);
      const num = matchNum ? matchNum[1] : idx;
      return (
        <li key={idx} className="ml-5 list-decimal text-sm text-slate-700 leading-relaxed my-1">
          {finalContent}
        </li>
      );
    }
    
    return <p key={idx} className="text-sm text-slate-700 leading-relaxed my-1.5 min-h-[1px]">{finalContent}</p>;
  });
};

export default function App() {
  // Config States
  const [activeTemplateKey, setActiveTemplateKey] = useState<string>('general');
  const [roleName, setRoleName] = useState<string>('');
  const [tone, setTone] = useState<ToneType>('empathetic');
  const [temperature, setTemperature] = useState<number>(0.7);
  const [systemInstruction, setSystemInstruction] = useState<string>('');
  const [initialGreeting, setInitialGreeting] = useState<string>('');
  
  // App Notification status
  const [copiedSection, setCopiedSection] = useState<'prompt' | 'greeting' | 'all' | null>(null);
  
  // Active Chat Session States
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [apiStateDetected, setApiStateDetected] = useState<'simulated' | 'live'>('simulated');
  
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initialize variables when template changes
  useEffect(() => {
    const original = PROMPT_TEMPLATES[activeTemplateKey];
    if (original) {
      setRoleName(original.roleName);
      setTone(original.tone);
      setTemperature(original.temperature);
      setSystemInstruction(original.systemInstruction);
      setInitialGreeting(original.initialGreeting);
      
      // Reset Chat matching this template instantly
      setMessages([
        {
          id: 'welcome',
          sender: 'agent',
          text: original.initialGreeting,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [activeTemplateKey]);

  // Read environment variable check simulation (server proxy checks if a key is loaded)
  useEffect(() => {
    const testApiState = async () => {
      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [{ sender: 'user', text: 'ping' }],
            systemInstruction: 'ping',
            temperature: 0.1
          })
        });
        const data = await response.json();
        if (data.text && !data.text.includes("[Simulated Response")) {
          setApiStateDetected('live');
        } else {
          setApiStateDetected('simulated');
        }
      } catch (err) {
        setApiStateDetected('simulated');
      }
    };
    testApiState();
  }, []);

  // Sync scroll on chat messages append
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle system template custom revisions
  const handleResetToTemplateDefault = () => {
    const original = PROMPT_TEMPLATES[activeTemplateKey];
    if (original) {
      setRoleName(original.roleName);
      setTone(original.tone);
      setTemperature(original.temperature);
      setSystemInstruction(original.systemInstruction);
      setInitialGreeting(original.initialGreeting);
      
      setMessages([
        {
          id: 'welcome-reset',
          sender: 'agent',
          text: original.initialGreeting,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  // Chat message submit logic to Express Gemini API
  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputMessage;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    // Append user message
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    if (!customText) setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: updatedMessages.map(m => ({ sender: m.sender, text: m.text })),
          systemInstruction: `${systemInstruction}\nCurrent Tone Directive: Express with high priority inside ${tone} style.`,
          temperature: temperature
        })
      });

      if (!response.ok) {
        throw new Error('Server connection issue');
      }

      const data = await response.json();
      
      const agentMsg: ChatMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        text: data.text || 'I returned null response. Let me know if we can try standard triage.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, agentMsg]);
    } catch (error) {
      console.error(error);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'agent',
        text: `**Connection Error**: SithaIT database systems are currently experiencing heavy traffic. Let's make sure you are logged into official Sithafal VPN channels before trying again.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Copy Utilities
  const copyToClipboard = (text: string, section: 'prompt' | 'greeting' | 'all') => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const getFullCompiledClipboardMarkdown = () => {
    return `# === SITHAFAL TECHNOLOGIES IT AGENT SYSTEM CONFIGURATION ===
# Role Name: ${roleName}
# Configured Tone Target: ${tone.toUpperCase()}
# Output Temperature Constraint: ${temperature}

## System Instruction (System Prompt):
"""
${systemInstruction}
"""

## Initial Conversational Response Prompt Example:
"""
${initialGreeting}
"""`;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
      {/* Dynamic Master-Top Header Container */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 transition-shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          
          <div className="flex items-center space-x-3.5">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-100 flex items-center justify-center">
              <Terminal className="h-6 w-6 stroke-[2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">Sithafal Tech</span>
                <span className="text-xs text-slate-500 font-mono">v1.2 // Workspace Agent Builder</span>
              </div>
              <h1 className="text-lg font-bold text-slate-900 tracking-tight">IT Helpdesk Prompt Portal</h1>
            </div>
          </div>

          {/* Connected Framework Keys HUD */}
          <div className="flex items-center space-x-4">
            <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-full border text-xs font-medium transition-colors ${
              apiStateDetected === 'live' 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                : 'bg-amber-50 text-amber-800 border-amber-200'
            }`}>
              <div className={`h-2 w-2 rounded-full ${apiStateDetected === 'live' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`}></div>
              <span className="font-mono">
                {apiStateDetected === 'live' ? 'Live Gemini Hub Sync' : 'Simulated API Sandbox'}
              </span>
            </div>

            <button
              onClick={() => copyToClipboard(getFullCompiledClipboardMarkdown(), 'all')}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:indigo-800 text-white font-medium text-xs rounded-lg transition-all shadow-sm cursor-pointer"
            >
              {copiedSection === 'all' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copiedSection === 'all' ? 'Copied Full Prompt!' : 'Export Prompt Packet'}</span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: System Prompt Workcell Grid (7cols Desktop) */}
        <section id="prompt-workbench" className="lg:col-span-7 flex flex-col space-y-5">
          <div className="bg-white border border-slate-200/95 rounded-2xl shadow-sm p-5 md:p-6 flex flex-col space-y-5">
            
            {/* Header / Sub-roles switch selectors */}
            <div className="flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sliders className="h-4 w-4 text-indigo-600" />
                  <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">IT Agent Persona Preset</h2>
                </div>
                <button 
                  onClick={handleResetToTemplateDefault}
                  className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-indigo-600 transition-colors"
                  title="Reset modifications to initial default settings"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Reset Default</span>
                </button>
              </div>

              {/* Grid cards for active agent presets */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: 'general', title: 'IT Triage Agent', subtitle: 'General Technical Issues' },
                  { key: 'access', title: 'Identity Agent', subtitle: 'MFA, VPN & Okta Portal' },
                  { key: 'hardware', title: 'Hardware Coordinator', subtitle: 'Laptops & Procurement' }
                ].map((item) => (
                  <button
                    key={item.key}
                    onClick={() => setActiveTemplateKey(item.key)}
                    className={`flex flex-col text-left p-3 rounded-xl border text-xs transition-all relative ${
                      activeTemplateKey === item.key
                        ? 'bg-indigo-50/50 border-indigo-500 ring-1 ring-indigo-500 font-semibold text-slate-900'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="font-bold truncate">{item.title}</span>
                    <span className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">{item.subtitle}</span>
                    {activeTemplateKey === item.key && (
                      <span className="absolute top-1 right-1 h-1.5 w-1.5 bg-indigo-600 rounded-full"></span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Config Parameter Customizers & Text Box */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Agent Role Title</label>
                <div className="relative">
                  <input
                    type="text"
                    value={roleName}
                    onChange={(e) => setRoleName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter support title code"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Output Tone Persona</label>
                <select
                  value={tone}
                  onChange={(e) => setTone(e.target.value as ToneType)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg text-slate-800 bg-slate-50 focus:bg-white focus:outline-gray-300 focus:outline"
                >
                  <option value="empathetic">Empathetic (Reassuring / Empathetic)</option>
                  <option value="professional">Professional (Accurate / Objective)</option>
                  <option value="technical">Technical (Structured / Instruction-driven)</option>
                </select>
              </div>
            </div>

            {/* Slider Constraints */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Creativity & Temperature</label>
                <span className="text-xs font-mono font-semibold text-indigo-600">{temperature}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-medium px-0.5 mt-0.5">
                <span>Precise & Logical (0.1)</span>
                <span>Optimized (0.7)</span>
                <span>More Creative (1.0)</span>
              </div>
            </div>

            {/* Master Box: System Instruction (Core prompt) */}
            <div className="flex-1 flex flex-col">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center space-x-1.5">
                  <Wrench className="h-3.5 w-3.5 text-indigo-500" />
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">System instructions prompt</label>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard(systemInstruction, 'prompt')}
                  className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center space-x-1"
                >
                  {copiedSection === 'prompt' ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedSection === 'prompt' ? 'Copied Instruction' : 'Copy Instruction'}</span>
                </button>
              </div>
              
              <div className="relative flex-1">
                <textarea
                  value={systemInstruction}
                  onChange={(e) => setSystemInstruction(e.target.value)}
                  className="w-full h-80 md:h-96 text-xs font-mono p-4 border border-slate-200 rounded-xl leading-relaxed text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 resize-none overflow-y-auto"
                  placeholder="Insert custom behavioral instructions representing Sithafal Technologies policies..."
                />
                <div className="absolute bottom-2 right-3 font-mono text-[9px] uppercase font-bold text-slate-400 bg-white/95 border border-slate-100 px-2 py-0.5 rounded-md shadow-sm pointer-events-none">
                  Editable Prompt Content
                </div>
              </div>
            </div>

            {/* Dynamic Placeholder Segment */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Greeting / Problem Placeholder Format
                </label>
                <button
                  type="button"
                  onClick={() => copyToClipboard(initialGreeting, 'greeting')}
                  className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center space-x-1"
                >
                  {copiedSection === 'greeting' ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedSection === 'greeting' ? 'Copied Greeting' : 'Copy Greeting'}</span>
                </button>
              </div>
              
              <textarea
                value={initialGreeting}
                onChange={(e) => setInitialGreeting(e.target.value)}
                className="w-full text-xs font-sans px-3 py-2.5 border border-slate-200 rounded-lg leading-relaxed text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                rows={4}
                placeholder="The initial greeting that initiates when an employee requests assistance..."
              />
              <p className="text-[10px] text-slate-400 mt-1 mb-0.5 leading-relaxed">
                * Note: Modifying this block initiates a fresh greeting in the simulated playfield on the right immediately.
              </p>
            </div>

          </div>

          {/* Quick IT Quick Factbox / Sithafal Knowledge summary */}
          <div className="bg-slate-900 text-slate-200 rounded-2xl border border-slate-800 p-5 shadow-inner">
            <div className="flex items-start space-x-3">
              <div className="p-1.5 bg-indigo-500/10 text-indigo-400 rounded-lg">
                <Info className="h-4.5 w-4.5" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400">Prompt Integration Overview</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  To deployment-ready this LLM configuration internally: paste the <strong>System Instructions</strong> directly into your LLM client configuration console (such as Vertex AI, Gemini Studio System Prompts, or third-party orchestrators) and issue the <strong>Greeting Placeholder</strong> to seed initial employee chats safely.
                </p>
                <div className="grid grid-cols-3 gap-2 pt-2.5 border-t border-slate-800 text-[10px] text-slate-400">
                  <div className="flex items-center space-x-1">
                    <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                    <span>VPN Compliance Built-In</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                    <span>Okta MFA Flow Guard</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                    <span>Hardware Lifecycle Aware</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Side: Chat Playfield Console (5cols Desktop) */}
        <section id="chat-sandbox" className="lg:col-span-5 flex flex-col h-[750px] lg:h-auto">
          <div className="bg-white border border-slate-200/95 rounded-2xl shadow-sm flex flex-col h-full overflow-hidden">
            
            {/* Playfield Header */}
            <div className="bg-slate-50 px-4 py-3.5 border-b border-slate-200/90 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                  <MessageSquare className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-950 uppercase tracking-widest">IT Sandbox Simulator</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Running custom prompt instructions above</p>
                </div>
              </div>

              {/* Reset Session state */}
              <button
                onClick={() => {
                  setMessages([
                    {
                      id: `welcome-${Date.now()}`,
                      sender: 'agent',
                      text: initialGreeting,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    }
                  ]);
                }}
                className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-lg transition-colors cursor-pointer"
                title="Clears session history, restoring to latest custom greeting placeholder"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>

            {/* Help guidelines banner */}
            <div className="px-4 py-2.5 bg-slate-50/50 border-b border-slate-100 flex items-center space-x-2 text-[11px] text-slate-600">
              <span className="font-mono text-indigo-600 font-bold">&#123;Info&#125;</span>
              <span>Test how modifications to tone or instructions affect SithaIT response outputs instantly.</span>
            </div>

            {/* Conversations Container */}
            <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4 bg-slate-50/20">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[90%] rounded-2xl px-4 py-3 shadow-xs space-y-1.5 leading-relaxed text-sm ${
                      m.sender === 'user'
                        ? 'bg-slate-900 text-slate-100 rounded-tr-none'
                        : 'bg-white border border-slate-200/70 text-slate-800 rounded-tl-none font-sans'
                    }`}
                  >
                    {/* Speaker Header label inside bubbles */}
                    <div className="flex items-center justify-between text-[10px] font-bold tracking-wider mb-1">
                      <span className={m.sender === 'user' ? 'text-indigo-400' : 'text-indigo-600 font-mono'}>
                        {m.sender === 'user' ? 'EMPLOYEE INQUIRY' : `🤖 ${roleName}`}
                      </span>
                      <span className="opacity-60 text-[9px] font-normal">{m.timestamp}</span>
                    </div>

                    {/* Rich text processor rendering lists/subheadings nicely */}
                    <div className="space-y-1 font-sans">
                      {m.sender === 'user' ? m.text : renderMarkdown(m.text)}
                    </div>
                  </div>
                </div>
              ))}

              {/* SithaIT response loading placeholder state */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-100 max-w-[85%] rounded-2xl rounded-tl-none px-4 py-3.5 shadow-sm space-y-2.5">
                    <div className="flex items-center space-x-1">
                      <span className="text-[10px] font-bold text-indigo-500 font-mono tracking-wider">SYSTEM DIAGNOSING...</span>
                    </div>
                    <div className="flex space-x-1.5 items-center justify-center py-2 px-10">
                      <div className="h-2 w-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="h-2 w-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="h-2 w-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={chatEndRef} />
            </div>

            {/* Quick Test Cards wrapper to instantly trigger standard cases */}
            <div className="p-3 bg-slate-50 border-t border-slate-200/90 space-y-2">
              <span className="block text-[10px] font-bold text-slate-400 tracking-wider uppercase">Quick Sandbox Inject Cases</span>
              <div className="flex flex-wrap gap-1.5">
                {QUICK_ISSUES.map((issue) => (
                  <button
                    key={issue.id}
                    onClick={() => {
                      setInputMessage(issue.description);
                      // Instantly prompt message for speed
                      handleSendMessage(issue.description);
                    }}
                    className="px-2.5 py-1.5 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-slate-700 text-[11px] rounded-lg font-medium shadow-xs transition-colors flex items-center space-x-1 cursor-pointer"
                  >
                    <span>{issue.label}</span>
                    <ArrowRight className="h-2.5 w-2.5 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>

            {/* Bottom sticky key input bar */}
            <div className="p-4 bg-white border-t border-slate-200">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center space-x-2"
              >
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask SithaIT anything related SithaVPN, logins, or hardware..."
                  className="flex-1 text-xs px-3 py-2.5 border border-slate-200 rounded-lg text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !inputMessage.trim()}
                  className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white rounded-lg shadow-sm transition-colors flex items-center justify-center cursor-pointer"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
              <div className="flex items-center justify-between mt-2.5 text-[10px] text-slate-400">
                <span className="flex items-center space-x-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Sithafal Tech Security Safe (SSL)</span>
                </span>
                <span>Press Enter to Send</span>
              </div>
            </div>

          </div>
        </section>

      </main>

      {/* Footer Branding credits */}
      <footer className="bg-white border-t border-slate-200 text-center py-4 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-1.5">
          <span>&copy; 2026 Sithafal Technologies Inc. Private IT Workspace Sandbox.</span>
          <span className="flex items-center space-x-1">
            <Lock className="h-3 w-3" />
            <span>Confidential Internal Use Only</span>
          </span>
        </div>
      </footer>
    </div>
  );
}

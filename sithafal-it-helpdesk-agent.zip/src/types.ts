export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
}

export type ToneType = 'empathetic' | 'professional' | 'technical';

export interface PromptConfig {
  roleName: string;
  systemInstruction: string;
  initialGreeting: string;
  temperature: number;
  tone: ToneType;
}

export interface QuickIssue {
  id: string;
  label: string;
  description: string;
}

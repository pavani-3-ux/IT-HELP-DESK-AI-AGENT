import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;

let ai: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!ai) {
    ai = new GoogleGenAI({
      apiKey: apiKey || "MOCK_KEY",
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return ai;
}

const app = express();
const PORT = 3000;

app.use(express.json());

// API route to chat with Sithafal Helpdesk agent SithaIT
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, systemInstruction, temperature } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      // Graceful fallback simulation if key is not configured or placeholder
      const lastMsg = messages[messages.length - 1]?.text || "";
      let mockReply = "";
      
      const textLower = lastMsg.toLowerCase();
      if (textLower.includes("vpn") || textLower.includes("anyconnect")) {
        mockReply = `**[Simulated Response - Add your real GEMINI_API_KEY in Settings > Secrets to enable live AI]**\n\nHello, I completely understand how frustrating VPN disruptions can be when you're trying to access your workspace. \n\nLet's troubleshoot this step-by-step for SithaVPN:\n\n1. **Verify Official Address**: Double-check that your Cisco AnyConnect client is pointing to the official server: \`vpn.sithafal.com\`.\n2. **SSO Session**: Ensure you have an active session in SithaPortal (Okta) by navigating to \`sithafal.okta.com\` in your browser first.\n3. **Network Check**: Try disconnecting any personal home proxies or mobile hotspots, as they may block security handshakes.\n\nCould you share your Sithafal Employee ID so I can look up your VPN security credentials?`;
      } else if (textLower.includes("okta") || textLower.includes("mfa") || textLower.includes("login")) {
        mockReply = `**[Simulated Response - Add your real GEMINI_API_KEY in Settings > Secrets to enable live AI]**\n\nI understand you are having login/MFA issues with SithaPortal. \n\nUsually, authentication loops or failed pushes can be resolved by this action:\n\n1. Open your **Okta Verify** app on your registered mobile device and check if the device's clock is synchronized.\n2. Clear your browser cache or try accessing the portal via an Incognito glass.\n3. Remember: Sithafal Security team will **never** ask for your password, security questions, or multi-factor code.\n\nIf the push notification is still not coming through, please provide your Employee ID, and of course, I can issue an override in our active SSO registry.`;
      } else {
        mockReply = `**[Simulated Response - Add your real GEMINI_API_KEY in Settings > Secrets to enable live AI]**\n\nThank you for reaching out to SithaIT assistance. I understand you are seeking help regarding: "${lastMsg}". \n\nI am SithaIT, virtual agent for Sithafal Technologies. I'm fully ready to support you with hardware setup, Okta logins, workspace configurations, or software licensing. Let's dig deeper: could you provide your Employee ID or describe any error codes popping up?`;
      }
      return res.json({ text: mockReply });
    }

    const client = getGeminiClient();
    
    // Map of roles for Gemini: 'user' and 'model'
    const formattedContents = messages.map(m => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }]
    }));

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: systemInstruction || "You are SithaIT virtual support specialist at Sithafal Technologies.",
        temperature: typeof temperature === 'number' ? temperature : 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: error?.message || "Internal server error connecting to Gemini API." });
  }
});

// Configure Vite or Serve static files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
